CREATE TRIGGER default_student_email
BEFORE INSERT ON student
FOR EACH ROW
  SET NEW.email = CONCAT(NEW.username, '@siue.edu');
